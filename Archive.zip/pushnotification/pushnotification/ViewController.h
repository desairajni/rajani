//
//  ViewController.h
//  pushnotification
//
//  Created by MAC OS on 3/8/16.
//  Copyright (c) 2016 MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIDatePicker *mydt;
@property (weak, nonatomic) IBOutlet UITextField *mytext;

- (IBAction)btnadd:(id)sender;
@end

