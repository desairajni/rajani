//
//  ViewController.h
//  SearchBarController
//
//  Created by MACOS on 7/29/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    NSMutableArray *arr;
    NSArray *searcharr;
    int a;
}

@property (weak, nonatomic) IBOutlet UITableView *tbl;

@end

