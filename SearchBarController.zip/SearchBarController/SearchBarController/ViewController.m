//
//  ViewController.m
//  SearchBarController
//
//  Created by MACOS on 7/29/16.
//  Copyright © 2016 MACOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    arr=[[NSMutableArray alloc]initWithObjects:@"iphone",@"dotnet",@"java",@"php",@"testing", nil];
    a=0;
    searcharr=[[NSArray alloc]init];
    
    UISearchBar *bar=[[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, 200, 40)];
    bar.delegate=self;
    bar.showsCancelButton=YES;
    
    UIBarButtonItem *item=[[UIBarButtonItem alloc]initWithCustomView:bar];
    self.navigationItem.rightBarButtonItem=item;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (a==1)
    {
        return [searcharr count];
    }
    else
    {
        return [arr count];
    }
}


-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    if (a==1)
    {
        cell.textLabel.text=[searcharr objectAtIndex:indexPath.row];
        return cell;
    }
    else
    {
        cell.textLabel.text=[arr objectAtIndex:indexPath.row];
        return cell;
    }
    
}

-(void) searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSPredicate *prd=[NSPredicate predicateWithFormat:@"SELF LIKE[cd] %@ OR SELF CONTAINS[c] %@",searchText,searchText];
    searcharr=[arr filteredArrayUsingPredicate:prd];
    NSSortDescriptor *sode=[[NSSortDescriptor alloc]initWithKey:nil ascending:YES ];
    searcharr=[searcharr sortedArrayUsingDescriptors:[NSArray arrayWithObject:sode]];
    
    if (searcharr != nil)
    {
        a=1;
    }
    else
    {
        a=0;
        searcharr=[[NSArray alloc]init];
    }
    
    [_tbl reloadData];
    
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    a=0;
    [_tbl reloadData];
}

@end
